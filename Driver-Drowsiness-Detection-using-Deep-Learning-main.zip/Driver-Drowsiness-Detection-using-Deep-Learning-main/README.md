
Tutorial Link:- https://www.youtube.com/watch?v=O5_--oZPbgQ&t=2s

Dataset Link:- http://mrl.cs.vsb.cz/eyedataset

Model .h5 file Link:- https://drive.google.com/file/d/1I3QstH0HH5NRqH8F0QU3yqa7Uu7uLxbO/view?usp=sharing

![Screenshot from 2023-01-25 14-12-32](https://user-images.githubusercontent.com/59412013/214517864-e7defd90-57c5-4524-be22-b2907dc41c02.png)
![Screenshot from 2023-01-25 14-12-59](https://user-images.githubusercontent.com/59412013/214517882-099ed7cd-d8b7-4c06-a471-db6375866751.png)






Data Preparation has been updated with train and test folder split automation.

If you have any doubt you can DM me on Instagram.
My Insta ID:- https://www.instagram.com/developer_ashish.py

Lets connect on LinkedIn:- https://www.linkedin.com/in/ashish-kushwaha-45201b179
